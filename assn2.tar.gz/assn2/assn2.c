/*
# Name: Franklin Colton Parry
# Course: CS3260 - 001
# Assignment:  #2

Promise of originality
I promise that this souce code file, in it's entirety, been
written by myself and by no other peron or persons.  If at any time an
exact copy of this source code is found to be used by another person in
this term, I understand that both myself and the student that submitted
the copy will recieve a zero on this assignment.
*/

#include<stdio.h>  /* printf */
#include<unistd.h> /* fork  */
#include<stdlib.h> /* exit */


int main (int argc, char *argv[])
{

	pid_t pid;
        int err = 0;

	char * argument = argv[1]

	pid = fork();

	if( pid < 0)
	{
	  perror("Ooops, the fork  failed.");
	  exit(-1);
	}

	if(pid == 0)
	{
		printf("CHILD Started. \n");


		/* I couldn't figure out how to see how many arguments
		   were passed in.  */
		
		/* err = execl("/bin/ls", "ls", NULL); */
		
		err = execlp(argv[0], &argument); 

		/*err = execvp(argv[1], argv + 1);*/



		if (err < 0)
		{
			perror("The function failed");
		}

	} else 
	{
		printf("PARENT started, now waiting for process ID# %d\n", pid);

		wait(&err);
	
		printf("PARENT resumed. Child exit code of %d. Now terminating parent.\n", err);
	}

	return 0;

}

