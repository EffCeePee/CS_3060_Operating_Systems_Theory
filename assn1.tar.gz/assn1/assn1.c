/*
# Name: Franklin Colton Parry
# Course: CS3260 - 001
# Assignment:  #1

Promise of originality
I promise that this souce code file, in it's entirety, been
written by myself and by no other peron or persons.  If at any time an
exact copy of this source code is found to be used by another person in
this term, I understand that both myself and the student that submitted
the copy will recieve a zero on this assignment.
*/



#include<stdio.h>

int main(int argc, char * argv[])
{
	int i;
	int count = 0;

	printf("A program by F. Colton Parry  \n");

	for(i = 0; i < argc; i++)
	{
		printf("Argument # %d : %s \n", i, argv[i]);
		count++;
	}

	printf("Lines Printed: %d \n", count);

	return 0;


}

